
#pragma once

#include "com_if.h"
#include "com_extra.h"
#include "com_select.h"


void smpl_initialize( void );


void smpl_communicator( int iArgc, char **iArgv );

